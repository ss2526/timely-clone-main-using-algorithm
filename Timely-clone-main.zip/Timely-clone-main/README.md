# Timely-clone
This particular project is the clone of Timely  website which provides the service to the companies for managing their time and scheduling their work.
